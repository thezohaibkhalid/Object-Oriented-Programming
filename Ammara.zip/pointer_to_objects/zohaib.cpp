#include<iostream>
using namespace std;

class MyClass{
    public:
        void print(){
            cout<<" draw";
        }

};
int main()
{
    int* ptr = Myclass ;
    ptr.print();
}