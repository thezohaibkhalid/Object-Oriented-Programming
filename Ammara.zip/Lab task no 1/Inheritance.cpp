//
// Created by zohai on 31/05/2023.
//

/*
//
// Created by zohai on 31/05/2023.
//
#include<iostream>
using namespace std;

*/
/*
class Shape {
public:
    void display() {
        cout << "This is a shape." << endl;
    }
};

class Circle : public Shape {
public:
    void displayArea() {
        cout << "Area of the circle." << endl;
    }
};

int main() {
    Circle c;
    c.display();        // Accessing base class member function
    c.displayArea();    // Accessing derived class member function
    return 0;
}
*/

class zohaib{
public:
    void fun(){
        cout<<"This is parent class, ";
    }
};
class zohiab2: public:zohiab{
public:
    and(){
        cout<<"This is child :"

    }

};
int main(){
    zohiab2 A;
    A.fun();
    A.and();
}
/*
#include <iostream>
using namespace std;
int main(){
    cout<<"THis is just a main function !!!!";
}*/
