#include<iostream>
using namespace std;
/*
int main(){
	short x=20;
	
	int y=x;    //Implict type casting
	
	cout<<"The value of X is : "<<x<<endl;
	cout<<"The value of Y is : "<<y;
	return 0;
}
*/

int main(){
	
	double x=1.2;
	
	int y=(int)x;
	
	cout<<"The value of X is : "<<x<<endl;
	cout<<"The value of Y is : "<<y;
}
