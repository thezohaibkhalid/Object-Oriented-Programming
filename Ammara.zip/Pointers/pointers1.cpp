#include <iostream>
using namespace std;

int main()
{
    int a = 3;
    int* b = &a;
    // &-----> Adress of operator.
    // Derefrencing operator.
    // Pointer:- Data type which holds the adress of other data types,

    cout<<b;

    return 0;
}