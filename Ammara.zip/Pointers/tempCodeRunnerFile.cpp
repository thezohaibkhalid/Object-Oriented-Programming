    int* p_age {nullptr};
    double* p_name {nullptr};