#include<iostream>
using namespace std;
/*
int main(){
	
	double x = 1.3;
	
	int y = (int)x;
	
	cout<<"This is the value of X "<<x<<endl;
	cout<<"This is the Value of Y "<<y;
	
	return 0;
}

*/

int main(){
	
	int x=2;
	
	
	
	float y=x;
	
	cout<<"The value of X is "<<x<<endl;
	cout<<"The value of Y  is "<<y;
	
	return 0;
}
