/*

File handling-->
2 Types->
----->Sequential memory km lata ha but excess time zada hota ha.
----->Random memory zada lata ha but excess time km hota ha.
*/

#include<iostream>
#include <fstream>
#include <conio.h>
using namespace std;

int main()
{
    fstream obj;
    obj.open("text.text");
}
