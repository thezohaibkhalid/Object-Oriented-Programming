#include<iostream>
using namespace std;

class Base{
public:	
	void fun(){
		cout<<"This is a base class!!! ";
	}
};

class Derived: public Base{
public:
	void fun(){
		cout<<"This  Derived class!!! ";
	}
};

int main(){
	Derived obj;
	obj.fun();
	//obj.Base::fun();
	return 0;
}